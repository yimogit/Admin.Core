import{j as i}from"./index-CM8NDIlB.js";const d=(s,o,r)=>{o||r(),i(o)?r():r(new Error("字母+数字+可选特殊字符，长度在6-16之间"))};export{d as v};
