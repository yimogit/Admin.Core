const g=""+new URL("../svg/login-main-B7d9TLm_.svg",import.meta.url).href,n=""+new URL("../svg/login-bg-fJ974LCd.svg",import.meta.url).href;export{n as a,g as l};
